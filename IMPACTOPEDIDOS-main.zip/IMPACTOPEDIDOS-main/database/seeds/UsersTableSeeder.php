<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /* Trabajadores */
        $trabajadores =[
            [
                'dni'=>'08372118',
                'nombres' => 'Administrador',
                'apellido_paterno' => 'IMPACTO',
                'apellido_materno' => 'IMPACTO'
            ],
            [
                'dni'=>'75795415',
                'nombres' => 'Angie',
                'apellido_paterno' => 'Palacios',
                'apellido_materno' => 'Peña'
            ],
            [
                'dni'=>'72457846',
                'nombres' => 'Juan',
                'apellido_paterno' => 'Malaga',
                'apellido_materno' => 'Sulca'
            ],
            [
                'dni'=>'76481984',
                'nombres' => 'Moises',
                'apellido_paterno' => 'La Torre',
                'apellido_materno' => 'Davila'
            ],
            [
                'dni'=>'78481545',
                'nombres' => 'Jorge',
                'apellido_paterno' => 'Ronquillo',
                'apellido_materno' => 'Castillo'
            ]
        ];
        DB::table('trabajadores')->insert($trabajadores);

        /* Roles */
        $roles =[
            [
                'nombre' => 'Admin',
                'descripcion' => 'Administrador'
            ],
            [
                'nombre' => 'JefeCompras',
                'descripcion' => 'Jefe de Compras'
            ],
            [   
                'nombre' => 'JefeProduccion',
                'descripcion' => 'Jefe de Producción'
            ],
            [
                'nombre' => 'OperarioProduccion',
                'descripcion' => 'Operario de Producción'
            ],
            [
                'nombre' => 'AtencionCliente',
                'descripcion' => 'Atención al Cliente'
            ]
        ];
        DB::table('roles')->insert($roles);

       $users = [
            [
            'email' => 'admin@impacto.com',
            'password' => bcrypt('sigepe'),
            'trabajador_id'=>'1',
            'role_id'=> '1'
            ],
            [
            'email' => 'jcompras@impacto.com',
            'password' => bcrypt('sigepe'),
            'trabajador_id'=>'2',
            'role_id'=> '2'
            ],
            [
            'email' => 'jproduccion@impacto.com',
            'password' => bcrypt('sigepe'),
            'trabajador_id'=>'3',
            'role_id'=> '3'
            ],
            [
            'email' => 'oproduccion@impacto.com',
            'password' => bcrypt('sigepe'),
            'trabajador_id'=>'4',
            'role_id'=> '4'
            ],
            [
            'email' => 'acliente@impacto.com',
            'password' => bcrypt('sigepe'),
            'trabajador_id'=>'5',
            'role_id'=> '5'
            ]
        ];
        DB::table('users')->insert($users);
    }

}
