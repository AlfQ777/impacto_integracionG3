<?php

use Illuminate\Database\Seeder;

class EquiposTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('equipos')->insert([
            'nombre'=>'FUENTE ( GI-GN600-R VER.2.0 ) NEGRO| OEM | 600W',
            'cantidad' => '35',
            'unidad_medida' => '2'
        ]);

        DB::table('equipos')->insert([
            'nombre'=>'PROC. INTEL CORE I5 10400 ( BX8070110400 ) 2.9GHZ-12MB | LGA 1200',
            'cantidad' => '35',
            'unidad_medida' => '0'
        ]);

        DB::table('equipos')->insert([
            'nombre'=>'CÁMARA WEB 1080P HD',
            'cantidad' => '15',
            'unidad_medida' => '2'
        ]);                  

        DB::table('equipos')->insert([
            'nombre'=>'TARJETA GRÁFICA RTX 2060 SUPER 8GB GDDR6',
            'cantidad' => '55',
            'unidad_medida' => '0'
        ]);

        DB::table('equipos')->insert([
            'nombre'=>'TECLADO INALÁMBRICO K600 ( 920-008824 ) P/ SMART TV',
            'cantidad' => '52',
            'unidad_medida' => '2'
        ]);

        DB::table('equipos')->insert([
            'nombre'=>'MOUSE INALÁMBRICO 1850 ( U7Z-00001 ) NEGRO',
            'cantidad' => '150',
            'unidad_medida' => '1'
        ]); 

        DB::table('equipos')->insert([
            'nombre'=>'MONITOR DISPLAY 23.8" ( AD80HW ) | FHD | HDMI - VGA | IPS | 5MS | 60HZ |',
            'cantidad' => '55',
            'unidad_medida' => '2'
        ]);

        DB::table('equipos')->insert([
            'nombre'=>'SILLA GAMING PREMIUM ( 8113 ) | NEGRO C/ GRIS',
            'cantidad' => '52',
            'unidad_medida' => '3'
        ]);
    }
}
