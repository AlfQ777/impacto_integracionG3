<?php

use Illuminate\Database\Seeder;

class CategoriasTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('categorias')->insert([
            'nombre'=>'Placas Madre (MotherBoard)',
            'active' => '1'
        ]);

        DB::table('categorias')->insert([
            'nombre'=>'Fuentes de Poder',
            'active' => '1'
        ]);

        DB::table('categorias')->insert([
            'nombre'=>'Procesadores',
            'active' => '2'
        ]);   

        DB::table('categorias')->insert([
            'nombre'=>'Silla Gaming',
            'active' => '2'
        ]);

        DB::table('categorias')->insert([
            'nombre'=>'Case',
            'active' => '1'
        ]);

        DB::table('categorias')->insert([
            'nombre'=>'Cámaras Web',
            'active' => '1'
        ]);

        DB::table('categorias')->insert([
            'nombre'=>'Tarjetas Gráficas',
            'active' => '1'
        ]);

        DB::table('categorias')->insert([
            'nombre'=>'Teclados y Mouses',
            'active' => '1'
        ]);

        DB::table('categorias')->insert([
            'nombre'=>'Monitores',
            'active' => '1'
        ]);

        DB::table('categorias')->insert([
            'nombre'=>'Memorias RAM',
            'active' => '1'
        ]);
    }
}
