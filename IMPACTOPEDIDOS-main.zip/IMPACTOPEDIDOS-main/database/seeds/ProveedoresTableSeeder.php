<?php

use Illuminate\Database\Seeder;

class ProveedoresTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('proveedores')->insert([
            'razon_social'=>'LG Electronics Perú S.A',
            'ruc' => '20375755344',
            'direccion' =>'Av República de Colombia 791, San Isidro - Lima',
            'tipo' => '1',
            'costo_flete' => '200'
        ]);    	
        DB::table('proveedores')->insert([
            'razon_social'=>'Huawei del Perú S.A.C.',
            'ruc' => '20507646728',
            'direccion' =>'Calle Las Begonias 415 Of. 2301, San Isidro - Lima',
            'tipo' => '2',
            'costo_flete' => '180'
        ]);

        DB::table('proveedores')->insert([
            'razon_social'=>'Intel Perú S.A.C',
            'ruc' => '20100041520',
            'direccion' =>'AV. DOS DE MAYO NRO. 357 INT. 2, San Isidro - Lima',
            'tipo' => '1',
            'costo_flete' => '215'
        ]);

        DB::table('proveedores')->insert([
            'razon_social'=>'Microsoft Perú S.R.L.',
            'ruc' => '20254138577',
            'direccion' =>'Av. Victor Andres Belaunde Nro. 147 Dpto. 9, San Isidro - Lima',
            'tipo' => '1',
            'costo_flete' => '250'
        ]);

        DB::table('proveedores')->insert([
            'razon_social'=>'Gambyte Peru S.A.C.',
            'ruc' => '20605447857',
            'direccion' =>'Av. Inca Garcilaso de la Vega Nro. 1236 Int. 215 Cercado de Lima, Lima - Lima',
            'tipo' => '1',
            'costo_flete' => '235'
        ]);
    }
}
