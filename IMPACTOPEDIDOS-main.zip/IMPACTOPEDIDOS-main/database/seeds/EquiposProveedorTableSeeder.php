<?php

use Illuminate\Database\Seeder;

class EquiposProveedorTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'1',
            'proveedor_id' => '1',
            'precio_compra' => '160'
        ]);

        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'1',
            'proveedor_id' => '5',
            'precio_compra' => '155'
        ]);

        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'2',
            'proveedor_id' => '3',
            'precio_compra' => '930'
        ]);

        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'3',
            'proveedor_id' => '1',
            'precio_compra' => '177'
        ]);

        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'3',
            'proveedor_id' => '2',
            'precio_compra' => '150'
        ]);

        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'3',
            'proveedor_id' => '4',
            'precio_compra' => '180'
        ]);

        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'4',
            'proveedor_id' => '3',
            'precio_compra' => '1680'
        ]);

        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'5',
            'proveedor_id' => '1',
            'precio_compra' => '50'
        ]);

        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'5',
            'proveedor_id' => '2',
            'precio_compra' => '55'
        ]);

        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'5',
            'proveedor_id' => '4',
            'precio_compra' => '66'
        ]);

        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'5',
            'proveedor_id' => '5',
            'precio_compra' => '40'
        ]);

        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'6',
            'proveedor_id' => '1',
            'precio_compra' => '25'
        ]);

        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'6',
            'proveedor_id' => '4',
            'precio_compra' => '28'
        ]);

        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'6',
            'proveedor_id' => '5',
            'precio_compra' => '21'
        ]);

        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'7',
            'proveedor_id' => '1',
            'precio_compra' => '588'
        ]);

        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'7',
            'proveedor_id' => '2',
            'precio_compra' => '615'
        ]);

        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'7',
            'proveedor_id' => '4',
            'precio_compra' => '550'
        ]);


        DB::table('equipos_proveedor')->insert([
            'equipo_id'=>'8',
            'proveedor_id' => '5',
            'precio_compra' => '1070'
        ]);

    }
}
