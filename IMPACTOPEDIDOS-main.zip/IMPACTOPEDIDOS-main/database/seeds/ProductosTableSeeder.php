<?php

use Illuminate\Database\Seeder;

class ProductosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('productos')->insert([
            'nombre'=>'SILLA GAMBYTE PREMIUM',
            'material' => '3',
            'unidad_medida'=>'1',
            'descripcion' => 'Marca: DXT,Modelo: DXT-1005-CB,Material: Cubierta de cuero PU,Mecanismo: -,Reclinable: 170°,Tipo apoyabrazos: REPOSABRAZOS AJUSTABLES',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902659905079627796/silla.jpg?width=960&height=731',
            'precio_unitario' => '1069.20',
            'categoria_id'=>'4'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'PROC. INTEL CORE I5 10400',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 
                'Gráficos integrados: Intel® UHD Graphics 630, Frecuencia del procesador turbo: 4.30 GHz, Frecuencia del procesador: 2.90 GHz',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902663927849181224/procesador-intel.jpg',
            'precio_unitario' => '935.55',
            'categoria_id'=>'3'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'PROC. AMD RYZEN 5 3600',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 'Marca: Amd,Modelo: Ryzen 5 3600,Socket: Am4,Frecuencia del procesador: 3.6GHZ,Frecuencia del 
            procesador turbo:4.2GHZ,Número de núcleos: 6,Litografía del procesador: no definido,Refrigerador incluido:si,
            Cache del procesador: hasta 32MB,Tipo de memoria que soporta:DDR4,Velocidad del reloj de memoria:3200HZ,Potencia 
            del diseño termico (TDP):65W,Gráficos integrados: no definido,Dimensiones:no definido',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902663931967979530/amd.jpg?width=960&height=731',
            'precio_unitario' => '1089.45',
            'categoria_id'=>'3'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'MB ASROCK A520M-HVS AM4',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 'Marca: Asrock,Modelo:A520M-HVS,Socket:AM4,Chipset:AMD A520,Tipo de memoria ram:DDR4,Ranuras 
            de memoria disponible:2,Tamaño máx:64Gb,Entradas del panel trasero:1 x Puerto PS/2 Teclado/Ratón 1 x puerto 
            HDMI 2 x puertos USB 2.0 4 x puertos USB 3.2 1 x Puerto LAN RJ-45 con LED,LAN:PCIE x1 Gigabit LAN 10/100/1000 
            Mb/s,Audio:Códec de audio Realtek ALC887,Tipo de motherboard:ATX,Dimensiones:23.0 cm x 20.1 cm',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902667510967570502/placa.jpg',
            'precio_unitario' => '299.70',
            'categoria_id'=>'1'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'FUENTE GAMBYTE B700W ( GI-B700W-N ) 700W',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 'FUENTE GAMBYTE B700W ( GI-B700W-N ) 700W',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902673115467890761/fuente.jpg',
            'precio_unitario' => '198.45',
            'categoria_id'=>'2'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'CASE GAMBYTE GOWA ( GTT1205A ) S/ FUENTE | NEGRO | 1 PANEL VIDRIO | LED- ROJO',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 'Bahías de unidades externas de 5.25: 1: Bahías de unidades internas de 2.5: Hasta 
            3 Bahías de unidad internas de 3.5: Hasta 3',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902673309089554503/case.jpg',
            'precio_unitario' => '194.40',
            'categoria_id'=>'5'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'FUENTE EVGA 500 GD ( 100-GD-0500-V1 ) 500W | GOLD',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 'Marca: Evga,Modelo: 100-GD-0500-V1,Potencia máx: 500W,Salidas: Conector principal 24(20+4) / 
            conector CPU 8(4+4) pines / conector periférico 3 pines / conector S-ATA 6 pines / Conector PCI-E 8(6+2) x 2 
            pines,Ventilador: 120mm,Certificado: 80 Plus Gold,Modular: No,Factor de forma: ATX,Dimensiones: 86 x 150 x 140 mm,
            Peso: 1.8kg',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902673321366282250/fuente2.jpg',
            'precio_unitario' => '319.95',
            'categoria_id'=>'2'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'TARJ. VIDEO PNY QUADRO P1000 V2 4GB DDR5',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 'MARCA: PNY,MODELO: VCQP1000V2-PB,CUDA CORES: 640,MEMORIA GPU: GDDR5 de 5 GB,ANCHO DE 
            BANDA DE MEMORIA : 80 GB / seg,INTERFAZ DE MEMORIA: 128 bits,CONECTORES DE PANTALLA: Mini-DisplayPort 1.4 x 4,
            INTERFAZ DEL SISTEMA: PCI Express 3.0 x16,ADAPTADORES MDP A DP: 4 Incluido,SOPORTE HDCP : Si,FACTOR DE FORMA: 
            2.713 de alto x 5.906 de largo ranura única,MANEJO TÉRMICO: Ventilador ultra silencioso,CONSUMO MÁXIMO DE ENERGÍA: 
            47 W,RESOLUCÍON DIGITAL MÁXIMA (2x ENLACES DP): 5120 x 2880 x24 bpp a 60 hz (7680 x 4320 x24 bpp a 60 hz)',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902673648056430612/tarjeta.jpg',
            'precio_unitario' => '1701.00',
            'categoria_id'=>'7'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'TARJ. VIDEO ZOTAC GEFORCE GTX 1650 4GB GDDR5',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 'MARCA: ZOTAC,MODELO: ZT-T16500F-10L,GPU: GeForce® GTX 1650,GeForce® GTX 1650 CUDA cores: 896,
            Memoria Video: 4GB GDDR5,Bus Memoria: 128-bit,Reloj del motor: Boost: 1695 MHz,Reloj de memoria: 8 Gbps,PCI Express: 
            3.0,Salida de Video: DisplayPort 1.4 / HDMI 2.0b / Dual Link DVI-D,Soporta HDCP: Yes,Recomendad fuente de poder: 
            300W,Consumo de Energia: 75W,DirectX: 2 API feature level 12_1,OpenGL: 4.5',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902673649943859231/tarjeta2.jpg?width=960&height=731',
            'precio_unitario' => '1591.65',
            'categoria_id'=>'7'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'TARJ. VIDEO MSI GEFORCE GTX 1660 SUPER 6GB GDDR6',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 'Marca: Msi,Modelo: 912-V375-446,CUDA: 1408 Unidades,Velocidad de reloj del procesador: 1830 MHz,
            Capacidad de memoria gráfica: 6GB,Tipo de memoria gráfica: GDDR6,Ancho de datos: 14 Gbps,Tipo de interfaz: PCI Express 
            x16 3.0,Entradas: DisplayPort x 3 (v1.4) / HDMI 2.0b x 1,Número de ventiladores: 2,PSU recomendado: 450 W,Dimensiones: 
            247 x 127 x 46 mm',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902673653580312636/tarjeta3.jpg',
            'precio_unitario' => '2207.25',
            'categoria_id'=>'7'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'COMBO GAMBYTE DESTROYER ( GI-DESTROYER-MR ) GAMING | TECLADO+MOUSE | MECANICO |',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 'Marca : GAMBYTE
            Modelo:	GI-DESTROYER-MR
            Características: GAMING | TECLADO+MOUSE | MECANICO',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902674770498318336/teclado.jpg?width=960&height=731',
            'precio_unitario' => '210.60',
            'categoria_id'=>'8'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'MOUSE GAMBYTE ARROW G ( GI-ARROWG ) GAMING | LED- RGB',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 'MARCA: GAMBYTE,MODELO: ARROWG,FORMA:: ERGONOMICO,CONEXION:: CABLEADO,ILUMINACION:: RGB BLACKLIGHT,
            BOTONES:: 7 BOTONES,PULSACIONES:: 20 MILLONES,SENSOR OPTICO: PAW3327,RESOLUCION MAXIMA: 6200 DPI,VELOCIDAD MAXIMA: 220 
            IPS,ACELERACION MAXIMA: 30G,VELOCIDAD DE POLLING: 1000HZ (1MS),TIPO DE CABLE: TRENZADO,DIMENSIONES: 122X67X42',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902674772402503690/mouse.jpg?width=960&height=732',
            'precio_unitario' => '117.45',
            'categoria_id'=>'8'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'CAMARA WEB ADESSO CYBERTRACK H6',
            'material' => '1',
            'unidad_medida'=>'0',
            'descripcion' => 'CAMARA WEB ADESSO CYBERTRACK H6 ( CYBERTRACK H6 ) 1080P HD | 4K ULTRA',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902674775170748416/camara.jpg?width=960&height=731',
            'precio_unitario' => '342.23',
            'categoria_id'=>'6'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'MONITOR GIGABYTE AORUS LED 27"',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 'MARCA: MSI ,MODELO: 911-7B17-002 ,MEMORIA DDR4: 4400(OC)/ 4300(OC)/ 4266(OC)/ 4200(OC)/ 
            4133(OC)/ 4000(OC)/ 3866(OC)/ 3733(OC)/ 3600(OC)/ 3466(OC)/ 3400(OC)/ 3333(OC)/ 3300(OC)/ 3200(OC)/ 3000(OC) 
            / ,CPU (SOPORTE MÁXIMO): i9 ,PUERTO M.2: 2 PUERTOS SERIALES (FRONTALES) 1,CHIPSET: Intel® Z390 ,PUERTOS USB 3.1 
            (FRONTALES): 1(Gen2 Tipo C) 4(Gen1 Tipo A) ,CANAL DE MEMORIA: Doble ,RANURAS DIMM: 4 ,PCI-EX16: 3 ,PUERTOS USB 3.1 
            (TRASEROS): 1(Gen2 Tipo C) 1(Gen2 Tipo A) 2(Gen1 Tipo A) ,PCI-E GEN: Gen3 ,PCI-EX1: 3 ,SATAIII: 6 ,PUERTOS USB 2.0 
            (FRONTALES): 4',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902674777611841566/monitor.jpg',
            'precio_unitario' => '2401.65',
            'categoria_id'=>'9'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'MONITOR SAMSUNG LED 49" CRG9',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 'MONITOR SAMSUNG LED 49" CRG9 ( C49RG90SSL ) GAMING | CURVO | HDMI - 2 DP - USB',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902674779843207228/monitor2.jpg?width=960&height=731',
            'precio_unitario' => '5795.55',
            'categoria_id'=>'9'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'MEM. RAM HYPERX FURY DDR4 4GB/2666',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 'Marca: HYPERX
            Modelo:	HX426C16FB3/4
            Capacidad: 4GB
            Frecuencia: 2666
            Tipo de memoria: DDR4',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902681845722914856/memoria.jpg',
            'precio_unitario' => '137.70',
            'categoria_id'=>'10'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'MEM. RAM CRUCIAL BALLISTIX DDR4 16GB/2666',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => '
            Marca: CRUCIAL
            Modelo:	BL16G26C16U4B
            Capacidad: 16GB
            Frecuencia: 2666
            Tipo de memoria: DDR4',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902674784444350504/memoria2.jpg',
            'precio_unitario' => '388.80',
            'categoria_id'=>'10'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'PROC. INTEL CORE I9 9900K',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 'Marca: INTEL
            Modelo: BX806849900K
            Socket: LGA 1151
            Frecuencia del procesador: 3,60 GHz
            Frecuencia del procesador turbo: 5,00 GHz
            Número de núcleos: 8',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902676043264053268/procesador.jpg?width=960&height=731',
            'precio_unitario' => '2146.50',
            'categoria_id'=>'3'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'SILLA GAMBYTE PREMIUM',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 'SILLA GAMBYTE PREMIUM ( VC03- 09- GBE ) GAMING | NEGRO C/ BLANCO',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902676045176668170/silla.jpg?width=960&height=731',
            'precio_unitario' => '1336.50',
            'categoria_id'=>'4'
        ]);

        DB::table('productos')->insert([
            'nombre'=>'MEM. RAM HYPERX FURY DDR3 8GB/1600',
            'material' => '2',
            'unidad_medida'=>'0',
            'descripcion' => 'Modelo: HX316C10F/8
            Capacidad: 8 GB
            Frecuencia:	1600 MHZ
            Tipo de memoria: DDR3',
            'image'=>'https://media.discordapp.net/attachments/902659604025061440/902679866825146460/memoriaram.jpg',
            'precio_unitario' => '311.85',
            'categoria_id'=>'10'
        ]);
    }
}
