<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
    	DB::statement('SET FOREIGN_KEY_CHECKS=0;');
    	DB::table('proveedores')->truncate();
        DB::table('roles')->truncate();
    	DB::table('users')->truncate();
        DB::table('trabajadores')->truncate(); 
        DB::table('equipos')->truncate();
        DB::table('categorias')->truncate(); 
        DB::table('productos')->truncate(); 
        DB::table('producto_equipos')->truncate(); 
        DB::table('equipos_proveedor')->truncate();   
        DB::table('productos_pedido')->truncate(); 
        DB::table('pedidos')->truncate();
    	DB::statement('SET FOREIGN_KEY_CHECKS=1;');

        $this->call([
        	UsersTableSeeder::class,
        	ProveedoresTableSeeder::class,
            EquiposTableSeeder::class,
            CategoriasTableSeeder::class,
            EquiposProveedorTableSeeder::class,
            ProductosTableSeeder::class,
            ProductoEquiposTableSeeder::class,
            PedidoTableSeeder::class,
            ProductosPedidoTableSeeder::class,
        ]);
    }
}
