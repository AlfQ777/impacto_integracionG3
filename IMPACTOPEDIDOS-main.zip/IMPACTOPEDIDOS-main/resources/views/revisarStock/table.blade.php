<div class="box">
  <div class="box-body">
    <table id="tabla-stock" class="table table-bordered table-striped">
    <caption>Tabla del stock por revisar</caption>
      <thead>
        <tr>
          <th scope="col">COD</th>
          <th scope="col">Nombre </th>
          <th scope="col">Tamaño </th>
          <th scope="col">Stock equipo </th>
          <th scope="col">Estado</th>
          @if(!Auth::user()->hasRole('AtencionCliente') &&
              !Auth::user()->hasRole('JefeCompras'))
            <th scope="col">Acciones</th>
          @endif
        </tr>
      </thead>
      <tbody>
        @foreach ($equipos as $equipo)
          <tr>
            <td>{{ $equipo->id }}</td>
            <td>
              <em class="mr-2 glyphicon glyphicon-cog"></em>
              <span style="font-size: 105%; font-weight: bold; ">{{ $equipo->nombre }}</span>
            </td>
            <td>{{ $equipo->getUnidadMedida() }}</td>
            <td>{{ $equipo->cantidad }}</td>
            <td>
              @if ($equipo->estado == 2)
                <label class="label label-warning">Solicitado</label>
                ({{ $equipo->solicitado }} unidades)
              @else
                <label class="label label-default">Sin solicitud</label>
              @endif
            </td>
            @if (!Auth::user()->hasRole('AtencionCliente') &&
                 !Auth::user()->hasRole('JefeCompras'))
              <td>
                <button class="btn btn-xs btn-info" data-toggle="modal"
                  data-target="#equipoProveedorModal" data-id="{{ $equipo->id }}"> <span
                    class="fa fa-hand-o-up"></span> &nbsp;
                  Solicitar equipo
                </button>
              </td>
            @endif
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>
