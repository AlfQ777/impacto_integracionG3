<form action="{{route('asignacion.store')}}" method="post">
  @csrf
  <div class="col-md-6">
      <!-- general form elements -->
    <div class="box box-success">
      <div class="box-header with-border">
        <h3 class="box-title">Datos equipo&nbsp;|&nbsp; <strong> Asignar equipo a Proveedor</strong></h3>
      </div><!-- /.box-header -->
      <div class="box-body">
        <div class="row">
          <div class="col-md-12">
             <div class="form-group">
              <label for="proveedor">Proveedor <span class="mandatory">*</span></label>
              <select class="form-control" id="proveedor" name="proveedor_id">
                @isset($proveedores)
                    @foreach ( $proveedores as $proveedor)
                      <option selected="true" value="{{$proveedor->id}}">{{$proveedor->razon_social}}</option>
                    @endforeach
                @endisset
              </select>            
            </div>
          </div>
          
        </div>
        <div class="row">
          <div class="col-md-7">
            <div class="form-group @error('equipo_id') has-error @enderror">
              <label for="equipo_id">Equipo <span class="mandatory">*</span></label>
              <select name="equipo_id" id="equipo_id" class="form-control" required="">
                <option value="-1">Seleccione el proveedor primero</option>
              </select>
              @error('equipo_id')
                <span class="help-block" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
              @enderror
            </div>
          </div>
          <div class="col-md-5">
            <div class="form-group">
                <label for="equipo_id">Tamaño<span class="mandatory">*</span></label>
                <input type="text" id="unidad_medida" class="form-control" name="unidad_medida" readonly="" required="">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="form-group @error('precio_compra') has-error @enderror" id="datos-asignacion">
              <label for="precio_compra">Precio del equipo por cada Tamaño <span class="mandatory">*</span></label>
              <input id="precio_compra" type="number" class="form-control" name="precio_compra" placeholder="Ingrese el precio del proveedor al que vende el equipo" value="{{ old('precio_compra') }}" required="" min="1" step="0.01" disabled="true">
              @error('precio_compra')
                <span class="help-block" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
              @enderror
            </div>            
          </div>
        </div>

      </div><!-- /.box-body -->
      <div class="box-footer">
        <p>Los campos marcados con (<span class="mandatory" >*</span>) son obligatorios.</p>
        <button type="submit" class="btn pull-right bg-dark" style="color:#031f40">
            <em class="fa fa-chain"> </em>
              Asignar 
          </button>
          
      </div><!-- /.box-footer -->
    </div><!-- /.box -->
  </div>
</form>  
    <!--/.col (right) -->


