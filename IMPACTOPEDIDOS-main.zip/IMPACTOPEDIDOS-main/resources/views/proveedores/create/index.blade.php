@extends('layouts.main')

@section('title','Proveedores')

@section('styles')
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="{{asset('dist/css/alt/AdminLTE-select2.min.css')}}">
<link rel="stylesheet" href="{{asset('css/app.css')}}">
<style  rel="stylesheet" type="text/css">
  .mandatory {
    color: red;
    font-weight: bold;
  }
</style>
@endsection

@section('breadcrumb')
<ol class="breadcrumb" style="background-color: white !important">
  <li><a href="{{ route('home.index') }}">Inicio</a></li>
  <li><a href="{{ route('proveedores.index') }}">Proveedores</a></li>
  <li><a href="#"  class="text-muted">Registro</a></li>
</ol>
@endsection

@section('content')
<section class="content-header">
</section>
<section class="content">
  <div class="row">
    @include('proveedores.create.register')
    @include('proveedores.create.assignment')
  </div>
</section>
@endsection

@section('scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/js/select2.min.js"></script>
<script src="{{ asset('js/proveedor.js') }}"></script> 
<script type="text/javascript">

$(document).ready(function () {
  
  $('input[type=number][max]:not([max=""])').on('input', function(ev) {
    var $this = $(this);
    var maxlength = $this.attr('max').length;
    var value = $this.val();
    if (value && value.length >= maxlength) {
      $this.val(value.substr(0, maxlength));
    }
  });

  $select_equipo = $("#equipo_id");
  $datos_asignacion = $('#datos-asignacion :input').prop('disabled', true);
  let $proveedor = $('#proveedor');
  inicializarSelect2($proveedor, 'Seleccione el proveedor', '');
 $proveedor.on('change', function () {
    let id_proveedor = $proveedor.val();
    if (id_proveedor) {
      getEquiposSinAsignar(id_proveedor).done((data) => {
        console.log(data);
        $select_equipo.html('');
        inicializarSelect2($select_equipo, 'Seleccione el equipo a asignar', data.equipos);
        if (data.equipos.length >= 1) {
          const id_equipo = $select_equipo.val();
          handleequiposChanges(id_equipo);
          $datos_asignacion.prop('disabled', false);
        }else {
          toastr.info('El proveedor ya está asignado a todos los equipos', 'Info Alert', { timeOut: 3000 });
        }
      }).fail((error) => {
        toastr.error('Ocurrio un Error!', 'Error Alert', { timeOut: 2000 });
      });
    } 
    
  });

 $select_equipo.on('change', function () {
    let id_equipo = $select_equipo.val();
    handleequiposChanges(id_equipo);
   });
});


function handleequiposChanges(id_equipo){
  if (id_equipo) {
    getEquipoById(id_equipo).done((data) => {
      console.log(data);
      $('#unidad_medida').val(getUnidadMedida(data.equipo.unidad_medida));    
    }).fail((error) => {
      toastr.error('Ocurrio un Error!', 'Error Alert', { timeOut: 2000 });
    });
  } else {
    $('#unidad_medida').val('');
  }
}


function inicializarSelect2($select, text, data) {
  $select.prop('selectedIndex', -1);
  $select.select2({
    placeholder: text,
    allowClear: true,
    data: data
  }); 
}

function getEquiposSinAsignar(id_proveedor) {
  return $.ajax({
    type: 'GET',
    url: `../asignacion/${id_proveedor}/edit`,
    dataType: 'json',
  });
}   

function getEquipoById(id_equipo) {
  return $.ajax({
    type: 'GET',
    url: `../equipos/${id_equipo}`,
    dataType: 'json',
  });
}  

function getUnidadMedida(u_medida){
  result="";
  switch(u_medida){
     
     case 3:
          result="Grande";
          break;
      case 2: 
          result="Mediano";
          break;
      case 1: 
          result="Pequeño";
          break;
      case 0:
          result="No definido";
          break;
  }
  return result;   
}

</script>
@endsection



