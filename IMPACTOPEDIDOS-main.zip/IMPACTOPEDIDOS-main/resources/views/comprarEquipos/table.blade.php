<div>
  <div class="box">
    <div class="box-body">
      <table id="tabla-equipos-solicitados" class="table table-bordered table-striped">
      <caption>Tabla de equipos solicitados</caption>
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Equipo  </th>
            {{-- <th scope="col">Stock equipo </th> --}}
    {{--         <th scope="col">Tamaño </th> --}}
            <th scope="col">Proveedor</th>
            <th scope="col">Precio x Unidad</th>
            <th scope="col">Solicitado</th>   
            <th scope="col">Costo </th> 
            <th scope="col">Estado</th>  
            <th scope="col">Acciones</th>
          </tr>
        </thead>
        <tbody>
          @foreach ($equipos as $equipo)
            <tr>
              <td>{{$loop->iteration}}</td>
              <td>
              <em class="mr-2 glyphicon glyphicon-cog"></em>     
                <span style="font-size: 105%; font-weight: bold; " >{{$equipo->nombre}}</span>
              </td>
              <td>{{$equipo->razon_social}}</td>
              <td>S/. {{$equipo->precio_compra}}</td>
              <td>{{$equipo->solicitado}} unidades</td>
              <td>S/. {{$equipo->getMontoSolicitud()}}</td> 
              <td>
                @if($equipo->estado==2)
                  <label for="" class="label label-warning">{{$equipo->getEstadoSolicitud()}}</label>
                @else
                  <label for="" class="label label-info">{{$equipo->getEstadoSolicitud()}}</label>
                @endif
                <label for=""></label>
              </td>
              <td>
                @if($equipo->estado==2)
                <button class="btn btn-xs btn-primary" data-toggle="modal" data-target="#modal-aprobar-solicitud" data-id="{{$equipo->id}}" data-proveedor="{{$equipo->razon_social}}" data-preciocompra="{{$equipo->precio_compra}}" 
                  data-solicitado="{{$equipo->solicitado}}" data-equipo="{{$equipo->nombre}}"
                  data-equipoproveedor="{{$equipo->equipo_proveedor_id}}"><span class="fa fa-check"></span>
                </button>
                <button class="btn btn-xs btn-danger" data-toggle="modal" data-target="#modal-rechazar-solicitud" data-id="{{$equipo->id}}" data-cantidad="{{$equipo->cantidad}}" data-equipoproveedor="{{$equipo->equipo_proveedor_id}}">
                 <span class="fa fa-close"></span> 
                </button>
                @else
                  <button class="btn btn-xs bg-dark" style="color:#031f40" data-toggle="modal" data-target="#modal-registrar-compra" data-id="{{$equipo->id}}" data-solicitado="{{$equipo->solicitado}}" data-equipoproveedor="{{$equipo->equipo_proveedor_id}}">
                   <span class="fa fa-plus"></span>  Registrar
                  </button>
                @endif

              </td>
            </tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div> <!-- end box -->
</div>
