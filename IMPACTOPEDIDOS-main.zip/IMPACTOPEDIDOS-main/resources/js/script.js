$('.box').on('click', function () {
  $('.box').removeClass('box-success');
  $(this).addClass('box-success');
})