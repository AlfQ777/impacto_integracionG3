<?php

namespace Tests\Unit\equipo;

use CorporacionPeru\Equipo;
use CorporacionPeru\ProveedorEquipo;
use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class GetMontoSolicitadoTest extends TestCase
{
    /**
     * A basic unit test example.
     * @group equipo
     * @return void
     */
    public function testGetMontoSolicitado()
    {
        $proveedorEquipo = ProveedorEquipo::create([
            'equipo_id'=>'2',
            'proveedor_id' => '2',
            'precio_compra' => '100',
            'cantidad' => '25',
            'estado' => '1'
        ]);
        $equipo = Equipo::join('equipos_proveedor', 'equipos_proveedor.equipo_id', '=', 'equipos.id')
            ->where('equipos_proveedor.id','=',$proveedorEquipo->id)
            ->select('equipos_proveedor.cantidad as solicitado', 'equipos_proveedor.precio_compra')
            ->first();
        $this->assertEquals(2500, $equipo->getMontoSolicitud());
        $proveedorEquipo->delete();

    }
}
