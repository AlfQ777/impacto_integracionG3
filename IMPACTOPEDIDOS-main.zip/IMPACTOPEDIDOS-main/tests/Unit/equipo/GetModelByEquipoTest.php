<?php

namespace Tests\Unit\equipo;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use CorporacionPeru\Equipo;

class GetModelByEquipoTest extends TestCase
{
    const ATTRIBUTE_PIVOT = 'pivot.equipo_id';
    /**
     * A basic unit test example.
     * @group equipo
     * @return void
     */
    public function testGetProductsByEquipo()
    {
        $equipo = Equipo::findOrFail(1); //get equipo 1
        $productos = $equipo->productos()->get();
        if ($productos->count()>0) {
            $this->assertTrue($productos->contains( self::ATTRIBUTE_PIVOT, 1));
        }
       
    }

    /**
     * A basic unit test example.
     * @group equipo
     * @return void
     */
    public function testGetProveedoresByEquipo()
    {
        $equipo = Equipo::findOrFail(2); //get equipo 2
        $proveedores = $equipo->proveedores()->get();
        if ($proveedores->count()>0) {
            $this->assertTrue($proveedores->contains(self::ATTRIBUTE_PIVOT, 2));
        }
       
    }

    /**
     * A basic unit test example.
     * @group equipo
     * @return void
     */
    public function testGetPivotByEquipo()
    {
        $equipo = Equipo::findOrFail(2); //get equipo 1
        $productos = $equipo->proveedorEquipo()->get();
        if ($productos->count()>0) {
            $this->assertTrue($productos->contains('equipo_id',2));
        }
       
    }
}
