<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use CorporacionPeru\Equipo;
use CorporacionPeru\ProveedorEquipo;

class GetEstadoSolicitudTest extends TestCase
{
    /**
     * A basic unit test example.
     * @group equipo
     * @return void
     */
    public function testGetEstadoSolicitudEquipoIsAprobado()
    {
        $proveedorEquipo = ProveedorEquipo::create([
                            'equipo_id'=>'2',
                            'proveedor_id' => '2',
                            'precio_compra' => '100',
                            'cantidad' => '20',
                            'estado' => '3'
                        ]);
        $equipo = Equipo::join('equipos_proveedor', 'equipos_proveedor.equipo_id',
                            '=', 'equipos.id')
                            ->where('equipos_proveedor.id','=',$proveedorEquipo->id)
                            ->first();
        $this->assertEquals('Aprobado', $equipo->getEstadoSolicitud());
        $proveedorEquipo->delete();

    }

      /**
     * A basic unit test example.
     * @group equipo
     * @return void
     */
    public function testGetEstadoSolicitudEquiposinSolicitud()
    {
        $proveedorEquipo = ProveedorEquipo::create([
                            'equipo_id'=>'2',
                            'proveedor_id' => '2',
                            'precio_compra' => '100',
                            'estado' => '1'
                        ]);
        $equipo = Equipo::join('equipos_proveedor', 'equipos_proveedor.equipo_id',
                            '=', 'equipos.id')
                            ->where('equipos_proveedor.id','=',$proveedorEquipo->id)
                            ->first();
        $this->assertEquals('Sin Solicitud', $equipo->getEstadoSolicitud());
        $proveedorEquipo->delete();
    }
}
