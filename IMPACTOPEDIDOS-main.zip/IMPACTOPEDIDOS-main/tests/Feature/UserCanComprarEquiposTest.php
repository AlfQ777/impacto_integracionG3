<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use CorporacionPeru\User;
use CorporacionPeru\ProveedorEquipo;

class UserCanComprarEquiposTest extends TestCase
{
    const URI_COMPRA_EQUIPOS  = '/comprar_equipos';
    const ALERT_STATUS        = 'status';
    const ID_INSUMO_PROVEEDOR = 'id_equipo_proveedor';

    /**
     * A basic feature test example.
     * @group feature
     * @return void
     */
    public function testUseCanSeeSolicitudesCompraequipos()
    {
        $this->actingAs(User::findOrFail(1));
        $response = $this->get(self::URI_COMPRA_EQUIPOS);
        $response->assertSeeText('Tabla de equipos solicitados');
        $response->assertViewHas('equipos');
        $response->assertStatus(200); //success
    }

    /**
     * A basic feature test example.
     * @group feature
     * @return void
     */
    public function testUseCanRejectSolicitud()
    {
        $this->actingAs(User::findOrFail(1));
        $proveedorEquipo = ProveedorEquipo::where('proveedor_id',1)->where('equipo_id',1)->first();
        $proveedorEquipo->cantidad += 20;
        $proveedorEquipo->estado = 2;
        $proveedorEquipo->save();
        // create solicitud
        $response = $this->json('POST', '/reject_equipo' , [self::ID_INSUMO_PROVEEDOR => $proveedorEquipo->id]);
        $response->assertSessionHas(self::ALERT_STATUS, 'Solicitud rechazada');
        $response->assertRedirect(self::URI_COMPRA_EQUIPOS);
        $response->assertStatus(302);  //redirect to /compra_equipos
    }

    /**
     * A basic feature test example.
     * @group feature
     * @return void
     */
    public function testUseCanApproveSolicitud()
    {
        $this->actingAs(User::findOrFail(1));
        $proveedorEquipo = ProveedorEquipo::where('proveedor_id',1)->where('equipo_id',1)->first();
        $proveedorEquipo->cantidad += 20;
        $proveedorEquipo->estado = 2;
        $proveedorEquipo->save();
        // create solicitud
        $response = $this->json('POST', '/approve_equipo' , [self::ID_INSUMO_PROVEEDOR => $proveedorEquipo->id]);
        $response->assertSessionHas(self::ALERT_STATUS, 'Solicitud aceptada');
        $response->assertRedirect(self::URI_COMPRA_EQUIPOS);
        $response->assertStatus(302);  //redirect to /compra_equipos
    }

    /**
     * A basic feature test example.
     * @group feature
     * @return void
     */
    public function testUseCanRegisterCompra()
    {
        $this->actingAs(User::findOrFail(1));
        $proveedorEquipo = ProveedorEquipo::where('proveedor_id',1)->where('equipo_id',1)->first();
        // create solicitud
        $response = $this->json('POST', '/registrar_compra', [self::ID_INSUMO_PROVEEDOR => $proveedorEquipo->id]);
        $response->assertSessionHas(self::ALERT_STATUS, 'Compra de equipos registrada');
        $response->assertRedirect(self::URI_COMPRA_EQUIPOS);
        $response->assertStatus(302);  //redirect to /compra_equipos
    }
}
