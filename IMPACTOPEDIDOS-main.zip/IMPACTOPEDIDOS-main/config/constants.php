<?php

return [
    /*
    |--------------------------------------------------------------------------
    |Constants to use 
    |--------------------------------------------------------------------------
    |
    |
    */

      'unidades_medida' => [ 
        ['id'=>0 , 'descripcion' => 'No definido'],
        ['id'=>1 , 'descripcion' => 'Pequeño'],
        ['id'=>2 , 'descripcion' => 'Mediano'],
        ['id'=>3 , 'descripcion' => 'Grande'],         
      ],
      'menu' => [
        "Proveedores",
        "Categorías",
        "Stock de equipos"
      ]

];