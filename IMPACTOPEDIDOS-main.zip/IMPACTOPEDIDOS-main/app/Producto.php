<?php

namespace CorporacionPeru;

use Illuminate\Database\Eloquent\Model;

class Producto extends Model
{
    const IMAGE = 'image'; 
    protected $table = 'productos';
    protected $primaryKey = 'id';
    protected $fillable= ['id','nombre','categoria_id' , 'material' ,'unidad_medida',
                         'descripcion', 'image', 'precio_unitario'];


    public function equipos()
    {
        return $this->belongsToMany(Equipo::class,'producto_equipos')->withPivot('cantidad');
    }   

    public function pedidos(){
        return $this->belongsToMany(Pedido::class,'productos_pedido')->withPivot('cantidad','pu','monto');
    }

    public function categoria()
    {
        return $this->belongsTo(Categoria::class);
    }  

    public function getMaterial(){
        switch($this->material){
            case 5: 
                $result="Gambyte";
                break;
            case 4: 
                $result="Intel";
                break;
            case 3: 
                $result="Microsoft";
                break;
            case 2: 
                $result="Huawei";
                break;
            case 1:
                $result="LG";
                break;
            default:
                    $result=""; 
        }
        return $result;
    }

    public function getUnidadMedida(){

        switch($this->unidad_medida){    
           case 3:
                $result="Grande";
                break;
            case 2: 
                $result="Mediano";
                break;
            case 1: 
                $result="Peueño";
                break;
            case 0:
                $result="No definido";
                break;
            default:
                    $result=""; 
        }
        return $result;
    }

}
