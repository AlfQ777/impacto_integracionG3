<?php

namespace CorporacionPeru;

use Illuminate\Database\Eloquent\Model;
use CorporacionPeru\Planta;

class ProveedorEquipo extends Model
{
    protected $table = 'equipos_proveedor';
    protected $primaryKey = 'id';
    protected $fillable= ['id','equipo_id','proveedor_id','precio_compra', 'cantidad', 'estado'];


    public function proveedores()
    {
        return $this->belongsToMany(Proveedor::class,'proveedor_id');
    } 

    public function equipos()
    {
        return $this->belongsToMany(Equipo::class);
    }

}

