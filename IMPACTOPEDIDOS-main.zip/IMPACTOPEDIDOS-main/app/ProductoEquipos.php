<?php

namespace CorporacionPeru;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class ProductoEquipos extends Model
{
    protected $table = 'producto_equipos';
}
