<?php

namespace CorporacionPeru\Http\Controllers;

use CorporacionPeru\Equipo;
use CorporacionPeru\ProveedorEquipo;
use Illuminate\Http\Request;
use CorporacionPeru\Notification;

class RevisarStockController extends Controller
{
    const REVISAR_STOCK= 'RevisarStockController@index';
    const INSUMO_ID = 'equipos.id';
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $equipos = Equipo::groupBy(self::INSUMO_ID)
            ->join('equipos_proveedor', 'equipos_proveedor.equipo_id', '=', self::INSUMO_ID)
            ->selectRaw('equipos.id, equipos.nombre, equipos.cantidad, equipos.unidad_medida, equipos_proveedor.equipo_id, MAX(equipos_proveedor.estado) AS estado, SUM(equipos_proveedor.cantidad) AS solicitado')
            ->orderBy(self::INSUMO_ID, 'DESC')
            ->get();

        return view('revisarStock.index', compact('equipos'));
    }

    /**
     * Realiza la solicitud de equipos, de los equipos pasados
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $ids_proveedor = $request->proveedor_id;
        for ($i=0; $i < count($ids_proveedor) ; $i++) { 
            $cantSolicitud = $request->cantidad[$i];
            if ($cantSolicitud != 0) {
                $proveedorEquipo = ProveedorEquipo::where('proveedor_id',$request->proveedor_id[$i])->where('equipo_id',$request->id_equipo)->first();
                $proveedorEquipo->cantidad += $cantSolicitud;
                $proveedorEquipo->estado = 2;
                $proveedorEquipo->save();
            }
        }
        Notification::setAlertSession(Notification::SUCCESS,'Solicitud agregada con éxito');
        return redirect()->action(self::REVISAR_STOCK);
    }

}
