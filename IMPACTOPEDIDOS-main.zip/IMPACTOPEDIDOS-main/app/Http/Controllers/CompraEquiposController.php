<?php

namespace CorporacionPeru\Http\Controllers;

use CorporacionPeru\Equipo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use CorporacionPeru\ProveedorEquipo;
use CorporacionPeru\Notification;

class CompraEquiposController extends Controller
{
    const INSUMO_ID= 'equipos.id';
    const COMPRA_EQUIPOS_INDEX = 'CompraEquiposController@index';
    /**
     * Mostrar todos los equipos con solicitudes
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $equipos = Equipo::groupBy(self::INSUMO_ID,'proveedores.id')
                    ->join('equipos_proveedor', 'equipos_proveedor.equipo_id', '=', self::INSUMO_ID)
                    ->join('proveedores', 'equipos_proveedor.proveedor_id', '=', 'proveedores.id')
                    ->selectRaw('equipos.id, equipos.nombre, equipos.cantidad,
                             equipos.unidad_medida, equipos_proveedor.equipo_id,
                             proveedores.razon_social,
                             equipos_proveedor.id as equipo_proveedor_id,
                             MAX(equipos_proveedor.estado) AS estado, equipos_proveedor.precio_compra,
                             SUM(equipos_proveedor.cantidad) AS solicitado')
                    ->where('estado','=','2')
                    ->orWhere('estado','=','3')
                    ->orderBy(self::INSUMO_ID, 'DESC')
                    ->get();

        return view('comprarEquipos.index', compact('equipos'));
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function rejectSolicitud(Request $request)
    {
        $id = $request->id_equipo_proveedor;
        $solicitudEquipo = ProveedorEquipo::findOrFail($id);
        $solicitudEquipo->estado = 1;
        $solicitudEquipo->cantidad = 0;
        $solicitudEquipo->save();
        Notification::setAlertSession(Notification::WARNING,'Solicitud rechazada');
        return redirect()->action(self::COMPRA_EQUIPOS_INDEX);
        
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function approveSolicitud(Request $request)
    {
        $id = $request->id_equipo_proveedor;
        $solicitudEquipo = ProveedorEquipo::findOrFail($id);
        $solicitudEquipo->estado = 3;
        $solicitudEquipo->save();
        Notification::setAlertSession(Notification::SUCCESS,'Solicitud aceptada');
        return redirect()->action(self::COMPRA_EQUIPOS_INDEX);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function registrarCompra(Request $request)
    {
        /** Transaction */
        DB::beginTransaction();
        try {
            $id = $request->id_equipo_proveedor;
            $solicitudEquipo = ProveedorEquipo::findOrFail($id);
            $id_equipo = $solicitudEquipo->equipo_id;
            $equipo = Equipo::findOrFail($id_equipo);
            $equipo->cantidad += $solicitudEquipo->cantidad;
            $solicitudEquipo->estado = 1;
            $solicitudEquipo->cantidad = 0;
            $solicitudEquipo->save();
            $equipo->save();
            Notification::setAlertSession(Notification::SUCCESS,'Compra de equipos registrada');
        DB::commit();
        return redirect()->action(self::COMPRA_EQUIPOS_INDEX);
        } catch (\Exception  $e) {
            DB::rollback();
            Notification::setAlertSession(Notification::DANGER,'Ocurrió un error en el servidor');
            return redirect()->action(self::COMPRA_EQUIPOS_INDEX);
        }
    }
}

