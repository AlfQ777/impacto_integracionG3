<?php

namespace CorporacionPeru\Http\Controllers;

use CorporacionPeru\Producto;
use Illuminate\Http\Request;
use CorporacionPeru\Notification;
use CorporacionPeru\Equipo;

class EquipoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getDisponibles(){
        $equipos = Equipo::where('cantidad','>',0)->get();
        return response()->json(['equipos' => $equipos]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return $request;
    }

    /**
     * Display the specified resource.
     *
     * @param  \CorporacionPeru\Equipo  $equipo
     * @return \Illuminate\Http\Response
     */
    public function show(Equipo $equipo)
    {
        $equipo = $equipo->load('proveedores');
        return response()->json(['equipo' => $equipo]);
    }

}
