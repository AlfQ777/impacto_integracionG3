<?php

namespace CorporacionPeru\Http\Controllers;
use Illuminate\Http\Request;
use CorporacionPeru\Proveedor;
use CorporacionPeru\ProveedorEquipo;
use CorporacionPeru\Equipo;
use CorporacionPeru\Http\Requests\StoreProveedorEquipoRequest;
use CorporacionPeru\Notification;

class ProveedorEquipoController extends Controller
{

    const PROVEEDOR_INSUMO_INDEX = 'ProveedorEquipoController@index';
    /**
     * Asigna un equipo a un proveedor
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreProveedorEquipoRequest $request)
    {
        ProveedorEquipo::create($request->validated());

        Notification::setAlertSession(Notification::SUCCESS,'Asignación creada con exito');
        return  back();
     
    }

    /**
     * Muestra el equipo proveedor
     *
     * @param  \CorporacionPeru\Proveedor  $proveedor
     * @return \Illuminate\Http\Response
     */
    public function show($proveedor_id)
    {
        $proveedor = Proveedor::findOrFail($proveedor_id);
        return view('proveedores.equipos.index',compact('proveedor'));
    }

    /**
     * Retorna equipos no asociados al proveedor
     *
     * @param  \CorporacionPeru\Proveedor  $proveedor
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $proveedor = Proveedor::findOrFail($id);
        $array_ids_equipo = $proveedor->equipos->pluck('id');
        $equipos = Equipo::whereNotIn('id',$array_ids_equipo)
            ->select('id', 'nombre as text')->get();
        return response()->json(['equipos' => $equipos]);
    }

    /**
     * Actualiza el precio de venta del equipo
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \CorporacionPeru\Proveedor  $proveedor
     * @return \Illuminate\Http\Response
     */
    public function update(StoreProveedorEquipoRequest $request)
    {
        $id=$request->id;
        $proveedorEquipo=ProveedorEquipo::findOrFail($id);
        $proveedorEquipo->update($request->validated());
        Notification::setAlertSession(Notification::SUCCESS,'Equipo asignado editado con exito');
        return  back();
    }

    /**
     * Desasigna un equipo a un proveedor
     *
     * @param  \CorporacionPeru\Proveedor  $proveedor
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $proveedorEquipo = ProveedorEquipo::findOrFail($id);
        if ($proveedorEquipo->cantidad > 0) {
            Notification::setAlertSession(Notification::WARNING,'Debes culminar el proceso de solicitud de este equipo primero');
            return  back();
        }
        ProveedorEquipo::destroy($id);
        Notification::setAlertSession(Notification::SUCCESS,'Equipo asignado removido con exito');
        return  back(); 
    }

}