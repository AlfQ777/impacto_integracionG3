<?php

namespace CorporacionPeru;

use Illuminate\Database\Eloquent\Model;

class Equipo extends Model
{
    protected $table = 'equipos';
    protected $primaryKey = 'id';
    protected $fillable= ['id', 'nombre','unidad_medida' ,'cantidad'];

    public function productos(){
        return $this->belongsToMany(Producto::class, 'producto_equipos');
    }

    public function proveedores(){
        return $this->belongsToMany(Proveedor::class, 'equipos_proveedor')->withPivot('precio_compra');
    }

    public function proveedorEquipo(){
        return $this->hasMany(ProveedorEquipo::class, 'equipo_id');
    }

    /**
     * Scope a query to only include equipos disponibles
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeDisponibles($query)
    {
        return $query->where('cantidad', '>', 0);
    }

   
    public function getMontoSolicitud(){
        $monto = $this->solicitado*$this->precio_compra;
        return round($monto,2);
    }

    public function getEstadoSolicitud(){

        switch($this->estado){
            case 3: 
                $result="Aprobado";
                break;
            case 2: 
                $result="Pendiente";
                break;
            case 1:
                $result="Sin Solicitud";
                break;
            default:
                $result="";
        }
        return $result;
    }

    public function getUnidadMedida(){

        switch($this->unidad_medida){
           
           case 3:
                $result="Grande";
                break;
            case 2: 
                $result="Mediano";
                break;
            case 1: 
                $result="Pequeño";
                break;
            case 0:
                $result="No definido";
                break;
            default:
                $result="";
        }
        return $result;
    }
}
