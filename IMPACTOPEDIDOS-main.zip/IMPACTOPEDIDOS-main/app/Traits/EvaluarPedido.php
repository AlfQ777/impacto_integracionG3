<?php

namespace CorporacionPeru\Traits;

use CorporacionPeru\Pedido;
use CorporacionPeru\Equipo;

trait EvaluarPedido {
    
    /**
     * Apruebe el pedido especificado
     * @param  
     * @return 
     */
    public function aprobarPedido($id_pedido) {

        $isAprobado = false;

        $order = Pedido::findOrFail($id_pedido);
        $orderProducts = $order->productos;
        $equipos = array();
        foreach ($orderProducts as $product) {
            $equiposProducto = $product->equipos;
            foreach ($equiposProducto as $equipo) {
                $equipos[$equipo->id] = 0;
                $equiposStock[$equipo->id] = $equipo->cantidad;
            }
        }

        foreach ($orderProducts as $product) {
            $equiposProducto = $product->equipos;
            foreach ($equiposProducto as $equipo) {
                $cantidadEquipoProducto = $equipo->pivot['cantidad'] * $product->material;
                $equipos[$equipo->id] += $cantidadEquipoProducto;
                if ($equipos[$equipo->id] > $equiposStock[$equipo->id]) {
                    $pedidoUpdate = Pedido::findOrFail($id_pedido);
                    $pedidoUpdate->estado_pedido = 4;
                    $pedidoUpdate->save();
                    return $isAprobado;// no hay equipos| FALSE
                }
            }
        }
        foreach($equipos as $key => $equipoCantidad) {
            $equipo = Equipo::findOrFail($key);
            $equipo->cantidad = $equipo->cantidad - $equipoCantidad;
            $equipo->save();
        }
        $pedidoUpdate = Pedido::findOrFail($id_pedido);
        $pedidoUpdate->estado_pedido = 2;
        $pedidoUpdate->save();
        return true; // aprobado! | TRUE
    }

}