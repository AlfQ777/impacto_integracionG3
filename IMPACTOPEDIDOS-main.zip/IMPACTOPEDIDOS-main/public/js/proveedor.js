$('#treeview-proveedores').on('click',function(event){
  $('#treeview-productos').removeClass("active");
  $('#stock-equipos').removeClass("active");
  $('#registrar-pedidos').removeClass("active");
  $('#treeview-usuarios').removeClass("active");
  $('#treeview-revision-pedidos').removeClass("active"); 
  $('#treeview-proveedores').addClass("active");
})


